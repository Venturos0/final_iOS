//
//  TableViewCell.swift
//  tw
//
//  Created by Aslan Alshanov on 30.05.2021.
//

import UIKit
import Kingfisher

class TableViewCell: UITableViewCell {
    
    public static let identifier: String = "TableViewCell"

    
    @IBOutlet weak var bgImage: UIImageView!
    @IBOutlet weak var nameText: UILabel!
    @IBOutlet weak var channelsText: UILabel!
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var sourceText: UILabel!
    
    public var article: MovieEntity.Article?{
        didSet{
            if let article = article{
                nameText.text = article.title
                channelsText.text = "Author: \(article.author ?? "")"
                sourceText.text = "\(article.articleDescription ?? " " )"
                let imgUrl = URL(string: article.urlToImage ?? "https://www.pngkey.com/png/detail/843-8430063_breaking-news-stickers-sky-news.png")
                posterImageView.kf.setImage(with: imgUrl)
            }
            }
        }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        bgImage.layer.cornerRadius = 20
        bgImage.layer.masksToBounds = true
        posterImageView.layer.cornerRadius = 12
        posterImageView.layer.masksToBounds = true
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
