//
//  ViewController.swift
//  tw
//
//  Created by Aslan Alshanov on 30.05.2021.
//

import UIKit
import Alamofire
import SafariServices

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    private var moviePresenter: MoviePresenter!
    
    private var movies: [MovieEntity.Article] = [MovieEntity.Article](){
        didSet{
            self.tableView.reloadData()
        }
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.separatorStyle = .none
        tableView.register(UINib(nibName: TableViewCell.identifier, bundle: Bundle(for: TableViewCell.self)), forCellReuseIdentifier: TableViewCell.identifier)
//        getTrendingMovies()
        callToViewModel()
        
        // Do any additional setup after loading the view.
    }
    func callToViewModel() {
        moviePresenter = MoviePresenter(self)
        moviePresenter.callAPIToFetchMovies()
    }
}
extension ViewController{
    
//    private func getTrendingMovies(_ page: Int? = nil) {
//        var params: [String: Any] = [:]
//        if let page = page {
//            params["page"] = page
//        }
//        AF.request(apiLink, method: .get, parameters: [:]).responseJSON { (response) in
//            switch response.result{
//            case .success:
//                if let data = response.data{
//                    do{
//                    let gamesRequest = try JSONDecoder().decode(MovieEntity.self, from: data)
//                        self.movies += gamesRequest.articles
//                    }catch{
//                        print(error)
//                    }
//                }
//
//            case .failure:
//                print("Failed to upload streams")
//            }
//        }
//
//    }
}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        moviePresenter.isValid(indexPath.row)
        
        if let url = URL(string: movies[indexPath.row].url ?? "https://www.google.com"){
            let safariVC = SFSafariViewController(url: url)
            present(safariVC, animated: true, completion: nil)
        }
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.height
        let deltaOffset = maximumOffset - currentOffset
        
        if deltaOffset <= 10 && currentOffset > 200 {
//            pageNumber += 1
//            getTrendingMovies(pageNumber)
        }
    }
    
}


extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: TableViewCell.identifier, for: indexPath) as! TableViewCell
        cell.article = movies[indexPath.row]
//        cell.nameText.text = movies[indexPath.row].title
//        cell.channelsText.text = "Author: \(movies[indexPath.row].author ?? "")"
//        cell.sourceText.text = "\(movies[indexPath.row].articleDescription ?? " " )"
//        let imgUrl = URL(string: movies[indexPath.row].urlToImage ?? "https://www.pngkey.com/png/detail/843-8430063_breaking-news-stickers-sky-news.png")
//        cell.posterImageView.kf.setImage(with: imgUrl)
        return cell
    }
}
extension ViewController: MoviePresenterDelegate {
    
    func callAPIToFetchMovies(_ movies: [MovieEntity.Article]) {
        self.movies = movies
    }
    
    func validate(_ isValid: Bool) {
        print(isValid)
    }
}




