//
//  MoviePresenter.swift
//  tw
//
//  Created by Aslan Alshanov on 17.06.2021.
//

import Foundation

protocol MoviePresenterDelegate: NSObjectProtocol {
    
    func callAPIToFetchMovies(_ movies: [MovieEntity.Article])
    func validate(_ isValid: Bool)
}

class MoviePresenter {
    
    private let networkManager = NetworkManager.shared
    weak var controller: MoviePresenterDelegate? = nil
    
    init(_ controller: MoviePresenterDelegate) {
        self.controller = controller
    }
    
    func callAPIToFetchMovies() {
        networkManager.request { [weak self] (movies) in
            self?.controller?.callAPIToFetchMovies(movies)
        }
    }
    
    func isValid(_ id: Int) {
        if id > 10 {
            controller?.validate(true)
        } else {
            controller?.validate(false)
        }
    }
}
