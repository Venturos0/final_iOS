//
//  MovieEntity.swift
//  tw
//
//  Created by Aslan Alshanov on 30.05.2021.
//

import Foundation

struct MovieEntity: Decodable {
    let articles: [Article]
    
    struct Article: Decodable {
        let author: String?
        let title: String?
        let articleDescription: String?
        let url: String?
        let urlToImage: String?
        
//        init(movie: NewsEntity){
//            self.author = movie.author
//            self.title = movie.title
//            self.articleDescription = movie.articleDescription
//            self.url = movie.url
//            self.urlToImage = movie.urlToImage
//        }
        
        enum CodingKeys: String, CodingKey {
            case author
            case title
            case articleDescription = "description"
            case url
            case urlToImage
        }
        
    }

}
