//
//  NetworkManager.swift
//  tw
//
//  Created by Aslan Alshanov on 17.06.2021.
//

import Foundation



final class NetworkManager {
    
    static let shared = NetworkManager()
    
    private var TRENDING_MOVIES_URL: URL? {
        return URL(string: "https://newsapi.org/v2/top-headlines?country=us&apiKey=57b17b7432bc45f4aac28c4c67cb4a85")
    }
    
    private init() {}
    
    func request(_ completion: @escaping ([MovieEntity.Article]) -> Void) {
        if let url = TRENDING_MOVIES_URL {
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                if error == nil {
                    if let data = data {
                        DispatchQueue.global().async {
                            do {
                                let movies = try JSONDecoder().decode(MovieEntity.self, from: data)
                                DispatchQueue.main.async {
                                    completion(movies.articles)
                                }
                            } catch {
                                print(error)
                            }
                        }
                    }
                } else {
                    print(error!)
                }
            }.resume()
        }
    }
}
